/*class revisor extends Cadastrado {
  
}*/