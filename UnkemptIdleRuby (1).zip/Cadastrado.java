class Cadastrado {
  protected String nome;
  protected String CPF;
  protected String email;
  protected String senha;


  public Cadastrado (String nome, String CPF, String email, String senha) {
    this.nome = nome;
    this.CPF = CPF;
    this.email = email;
    this.senha = senha;
  }
  public void setName(String nome) 
  {
    this.nome = nome;
  }
  public void setCPF(String CPF)
  {
    this.CPF = CPF;
  }
  public void setEmail(String email)
  {
    this.email = email;
  }
  public void setSenha (String senha)
  {
    this.senha = senha;
  }
  public String getName() {
    return this.nome;
  }
  public String getCPF() {
    return this.CPF;
  }
  public String getEmail() {
    return this.email;
  }
  public String getSenha() {
    return this.senha;
  }
}