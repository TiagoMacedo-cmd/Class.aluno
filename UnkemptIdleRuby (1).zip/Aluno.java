class aluno extends Cadastrado {
  private String nivel;
  private String escolha;

  public aluno (String nivel, String escolha, String nome, String CPF, String email, String senha) {
    super (nome, CPF, email, senha); /*com super o construtor olha com argumentos, sem super, olha o construtor sem argumentos. se não tem um sem argumentos ele explode.*/
    this.nivel = nivel;
    this.escolha = escolha;
  }
  public void setNivel(String nivel) {
    this.nivel = nivel;
  }
  public void setEscolha(String escolha) {
    this.escolha = escolha;
  }
  public String getEscolha() {
    return this.escolha;
  }
  public String getNivel() {
    return this.nivel;
  }
}

/*chama aluno
  ve nivel ve escolha
  manda pra materia escolhida e ve o nivel
  ve no arquivo da materia escolhida uma pergunta de nivel adequado*/