class Disciplina {
  protected String nome;
  protected String exercicio;

  public void setName(String nome)
  {
    this.nome = nome;
  }
  public void setExercicio(String exercicio)
  {
    this.exercicio = exercicio;
  }
  public String getExercicio(String exercicio)
  {
    return this.exercicio;
  }
}